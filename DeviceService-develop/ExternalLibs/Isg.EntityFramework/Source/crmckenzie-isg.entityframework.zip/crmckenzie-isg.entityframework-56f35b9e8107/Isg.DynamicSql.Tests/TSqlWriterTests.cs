﻿using System.Data;
using System.Linq;
using NSubstitute;
using NUnit.Framework;

namespace Isg.DynamicSql
{
    [TestFixture]
    public class TSqlWriterTests
    {
        [Test]
        public void ToCommand()
        {
            // Arrange: Declare any variables or set up any conditions
            //          required by your test.
            var dbCommand = Substitute.For<IDbCommand>();
            var commandFactory = Substitute.For<ICommandFactory>();
            commandFactory.CreateCommand().Returns(dbCommand);

            var writer = new TSqlWriter(commandFactory);

            // Act:     Perform the activity under test.
            var command = writer.ToCommand();

            // Assert:  Verify that the activity under test had the
            //          expected results
            Assert.That(command, Is.Not.Null);
            Assert.That(command.CommandText, Is.Null.Or.Empty);
            commandFactory.CreateCommand().Received(1);
        }

        [Test]
        public void Select()
        {
            // Arrange: Declare any variables or set up any conditions
            //          required by your test.
            var dbCommand = Substitute.For<IDbCommand>();
            var commandFactory = Substitute.For<ICommandFactory>();
            commandFactory.CreateCommand().Returns(dbCommand);

            var sql = new TSqlWriter(commandFactory);
            sql
                .Select("*");


            var baseQuery = "SELECT *";

            // Act:     Perform the activity under test.
            var result = sql.ToCommand().CommandText;

            // Assert:  Verify that the activity under test had the
            //          expected results
            Assert.That(result, Is.EqualTo(baseQuery));
        }
        
        [Test]
        public void SelectFrom()
        {
            // Arrange: Declare any variables or set up any conditions
            //          required by your test.
            var dbCommand = Substitute.For<IDbCommand>();
            var commandFactory = Substitute.For<ICommandFactory>();
            commandFactory.CreateCommand().Returns(dbCommand);

            var sql = new TSqlWriter(commandFactory);
            sql
                .Select("*")
                .From("MyTable");


            var baseQuery = "SELECT *\r\nFROM MyTable";

            // Act:     Perform the activity under test.
            var result = sql.ToCommand().CommandText;

            // Assert:  Verify that the activity under test had the
            //          expected results
            Assert.That(result, Is.EqualTo(baseQuery));
        }

        [Test]
        public void SelectFromJoin()
        {
            // Arrange: Declare any variables or set up any conditions
            //          required by your test.
            var dbCommand = Substitute.For<IDbCommand>();
            var commandFactory = Substitute.For<ICommandFactory>();
            commandFactory.CreateCommand().Returns(dbCommand);

            var sql = new TSqlWriter(commandFactory);
            sql
                .Select("M.*")
                .From("MyTable M")
                .Join("OtherTable OT ON M.id = OT.id")
                ;


            var baseQuery = "SELECT M.*\r\nFROM MyTable M\r\nJOIN OtherTable OT ON M.id = OT.id";

            // Act:     Perform the activity under test.
            var result = sql.ToCommand().CommandText;

            // Assert:  Verify that the activity under test had the
            //          expected results
            Assert.That(result, Is.EqualTo(baseQuery));
        }

        [Test]
        public void SelectFromWhere()
        {
            // Arrange: Declare any variables or set up any conditions
            //          required by your test.
            var dbCommand = Substitute.For<IDbCommand>();
            var commandFactory = Substitute.For<ICommandFactory>();
            commandFactory.CreateCommand().Returns(dbCommand);

            var sql = new TSqlWriter(commandFactory);
            sql
                .Select("M.*")
                .From("MyTable M")
                .Where("M.first_column = 1")
                ;


            var baseQuery = "SELECT M.*\r\nFROM MyTable M\r\nWHERE M.first_column = 1";

            // Act:     Perform the activity under test.
            var result = sql.ToCommand().CommandText;

            // Assert:  Verify that the activity under test had the
            //          expected results
            Assert.That(result, Is.EqualTo(baseQuery));
        }

        [Test]
        public void SelectFromWhereSingleParameter()
        {
            // Arrange: Declare any variables or set up any conditions
            //          required by your test.
            var sql = new TSqlWriter(new SqlServerCommandFactory());
            sql
                .Select("M.*")
                .From("MyTable M")
                .Where("M.first_column = {0}", 1);
                ;


            var baseQuery = "SELECT M.*\r\nFROM MyTable M\r\nWHERE M.first_column = @p0";

            // Act:     Perform the activity under test.
            var command = sql.ToCommand();
            var result = command.CommandText;

            // Assert:  Verify that the activity under test had the
            //          expected results
            Assert.That(result, Is.EqualTo(baseQuery));
            Assert.That(command.Parameters, Has.Count.EqualTo(1));
            IDataParameter dataParameter = command.Parameters.Cast<System.Data.IDataParameter>().First();
            Assert.That(dataParameter.ParameterName, Is.EqualTo("@p0"));
            Assert.That(dataParameter.Value, Is.EqualTo(1));
        }

        [Test]
        public void SelectFromWhereTwoParameter()
        {
            // Arrange: Declare any variables or set up any conditions
            //          required by your test.
            var sql = new TSqlWriter(new SqlServerCommandFactory());
            sql
                .Select("M.*")
                .From("MyTable M")
                .Where("M.first_column = {0} AND M.second_column = {1}", 1, 2);
            ;


            var baseQuery = "SELECT M.*\r\nFROM MyTable M\r\nWHERE M.first_column = @p0 AND M.second_column = @p1";

            // Act:     Perform the activity under test.
            var command = sql.ToCommand();
            var result = command.CommandText;

            // Assert:  Verify that the activity under test had the
            //          expected results
            Assert.That(result, Is.EqualTo(baseQuery));
            Assert.That(command.Parameters, Has.Count.EqualTo(2));

            var p0 = command.Parameters[0] as IDataParameter;
            Assert.That(p0.ParameterName, Is.EqualTo("@p0"));
            Assert.That(p0.Value, Is.EqualTo(1));

            var p1 = command.Parameters[1] as IDataParameter;
            Assert.That(p1.ParameterName, Is.EqualTo("@p1"));
            Assert.That(p1.Value, Is.EqualTo(2));
        }

        [Test]
        public void SelectFromWhereAndParameters()
        {
            // Arrange: Declare any variables or set up any conditions
            //          required by your test.
            var sql = new TSqlWriter(new SqlServerCommandFactory());
            sql
                .Select("M.*")
                .From("MyTable M")
                .Where("M.first_column = {0}", 1)
                .And("M.second_column = {0}", 2)
                ;


            var baseQuery = "SELECT M.*\r\nFROM MyTable M\r\nWHERE M.first_column = @p0\r\nAND M.second_column = @p1";

            // Act:     Perform the activity under test.
            var command = sql.ToCommand();
            var result = command.CommandText;

            // Assert:  Verify that the activity under test had the
            //          expected results
            Assert.That(result, Is.EqualTo(baseQuery));
            Assert.That(command.Parameters, Has.Count.EqualTo(2));
        
            var p0 = command.Parameters[0] as IDataParameter;
            Assert.That(p0.ParameterName, Is.EqualTo("@p0"));
            Assert.That(p0.Value, Is.EqualTo(1));

            var p1 = command.Parameters[1] as IDataParameter;
            Assert.That(p1.ParameterName, Is.EqualTo("@p1"));
            Assert.That(p1.Value, Is.EqualTo(2));
        
        }
    }
}
