using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;

namespace Isg.DynamicSql
{
    public class TSqlWriter
    {
        private readonly ICommandFactory _commandFactory;
        private readonly List<Segment> _segments = new List<Segment>();

        public TSqlWriter(ICommandFactory commandFactory)
        {
            _commandFactory = commandFactory;
        }

        public IDbCommand ToCommand()
        {
            var result = _commandFactory.CreateCommand();
            result.CommandText = GetCommandText();
            AddParametersToCommand(result);
            return result;
        }

        private void AddParametersToCommand(IDbCommand command)
        {
            var allParameters = _segments
                .Where(s => s.HasParameters())
                .SelectMany(s => s.Parameters)
                .ToArray();

            for (var i = 0; i < allParameters.Length; i++)
            {
                var parameter = _commandFactory.CreateParameter();
                parameter.ParameterName = string.Format("@p{0}", i);
                parameter.Value = allParameters[i];
                command.Parameters.Add(parameter);
            }
        }

        private string GetCommandText()
        {
            var builder = new System.Text.StringBuilder();
            var segmentsQueue = _segments.ToQueue();

            var parameterIndex = 0;

            while (segmentsQueue.Any())
            {
                var segment = segmentsQueue.Dequeue();
                var formattedStatement = segment.GetFormattedStatement(parameterIndex);
                if (segment.HasParameters())
                    parameterIndex += segment.Parameters.Length;

                if (segmentsQueue.Any())
                    builder.AppendLine(formattedStatement);
                else
                    builder.Append(formattedStatement);
            }
            var result = builder.ToString();
            return result;
        }

        public TSqlWriter Select(string statement)
        {
            const string keyword = "SELECT";
            var result = WriteStatement(keyword, statement);
            return result;
        }

        public TSqlWriter From(string statement)
        {
            const string keyword = "FROM";
            var result = WriteStatement(keyword, statement);
            return result;
        }
        
        public TSqlWriter Join(string statement)
        {
            const string keyword = "JOIN";
            var result = WriteStatement(keyword, statement);
            return result;
        }

        public TSqlWriter Where(string statement, params object[] parameters)
        {
            const string keyword = "WHERE";
            var result = WriteStatement(keyword, statement, parameters);
            return result;
        }

        public TSqlWriter And(string statement, params object[] parameters)
        {
            const string keyword = "AND";
            var result = WriteStatement(keyword, statement, parameters);
            return result;
        }

        private TSqlWriter WriteStatement(string keyword, string statement, params object[] parameters)
        {
            _segments.Add(new Segment()
            {
                KeyWord = keyword,
                Parameters = parameters,
                Statement = statement,
            });
            return this;
        }    
    }
}