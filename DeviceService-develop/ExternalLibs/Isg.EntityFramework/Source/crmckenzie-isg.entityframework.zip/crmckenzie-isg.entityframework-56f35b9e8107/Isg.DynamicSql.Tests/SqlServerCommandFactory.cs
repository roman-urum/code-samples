using System.Data;
using System.Data.SqlClient;

namespace Isg.DynamicSql
{
    public class SqlServerCommandFactory : ICommandFactory
    {
        public IDbCommand CreateCommand()
        {
            return new SqlCommand();
        }

        public IDataParameter CreateParameter()
        {
            return new SqlParameter();
        }
    }
}