using System.Data;

namespace Isg.DynamicSql
{
    public interface ICommandFactory
    {
        IDbCommand CreateCommand();
        IDataParameter CreateParameter();
    }
}