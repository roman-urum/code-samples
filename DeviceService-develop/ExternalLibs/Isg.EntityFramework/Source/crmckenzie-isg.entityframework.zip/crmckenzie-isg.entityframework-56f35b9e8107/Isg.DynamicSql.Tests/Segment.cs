using System.Linq;

namespace Isg.DynamicSql
{
    internal class Segment
    {
        public string KeyWord { get; set; }
        public string Statement { get; set; }
        public object[] Parameters { get; set; }

        public string GetFormattedStatement(int parameterIndex)
        {
            var formatResult = string.Format("{0} {1}", KeyWord, Statement);
            var parameterNames = GetParameterNames(parameterIndex);
            var result = string.Format(formatResult, parameterNames);
            return result;
        }

        public string[] GetParameterNames(int parameterIndex)
        {
            if (!HasParameters())
                return Enumerable.Empty<string>().ToArray();

            int lastParameterIndex = parameterIndex + Parameters.Length ;
            var query = from i in Enumerable.Range(parameterIndex, lastParameterIndex)
                        select string.Format("@p{0}", i);
            var results = query.ToArray();
            return results;
        }

        public bool HasParameters()
        {
            return Parameters != null && Parameters.Any();
        }
    }
}