using System.Collections.Generic;

namespace Isg.DynamicSql
{
    public static class EnumerableExtensions
    {
        public static Queue<T> ToQueue<T>(this IEnumerable<T> self)
        {
            var result = new Queue<T>();
            foreach(var t in self)
                result.Enqueue(t);
            return result;
        }
    }
}