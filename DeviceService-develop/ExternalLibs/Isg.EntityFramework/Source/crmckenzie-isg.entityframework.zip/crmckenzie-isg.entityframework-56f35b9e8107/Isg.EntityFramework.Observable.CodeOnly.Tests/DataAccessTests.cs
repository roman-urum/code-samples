﻿using System;
using System.Data.Entity;
using System.Linq;
using Isg.EntityFramework.ObservableProvider.TestModels;
using NUnit.Framework;

namespace Isg.EntityFramework.ObservableProvider.CodeOnly.Tests
{
    [TestFixture]
    public class DataAccessTests
    {
        [TestFixtureSetUp]
        public void BeforeAnyTestRuns()
        {
            ObservableProviderConfiguration.RegisterProvider("System.Data.SqlServerCe.4.0", setAsDefault:true);
            Database.SetInitializer(new DropCreateDatabaseIfModelChanges<NorthwindDbContext>());

            this.ConnectionString = "Data Source=Northwind.sdf;Persist Security Info=False;";
        }

        protected string ConnectionString { get; set; }

        [Test]
        public void InsertCategory()
        {
            var eventFired = false;

            Hub.ConnectionOpening += (sender, args) =>
                {

                };

            Hub.ConnectionClosing += (sender, args) =>
                {

                };

            Hub.CommandExecuting += (sender, args) =>
            {
                eventFired = true;
            };

            using (var context = new NorthwindDbContext(this.ConnectionString))
            {
                var newRecord = new Category()
                {
                    CategoryName = Guid.NewGuid().ToString()
                };

                context.Categories.Add(newRecord);
                context.SaveChanges();


                var categories = context.Set<Category>().ToList();
                foreach (var category in categories)
                    Console.WriteLine(category.CategoryName);
            }

            Assert.That(eventFired, Is.True);
        }
    }
}
