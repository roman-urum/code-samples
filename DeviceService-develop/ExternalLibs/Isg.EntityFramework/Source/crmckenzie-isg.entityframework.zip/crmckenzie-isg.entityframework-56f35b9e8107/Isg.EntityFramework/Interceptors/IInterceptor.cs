﻿using System.Data.Entity.Infrastructure;
using System.Text;

namespace Isg.EntityFramework.Interceptors
{
    public interface IInterceptor
    {
        void Before(InterceptionContext context);
        void After(InterceptionContext context);
    }
}
