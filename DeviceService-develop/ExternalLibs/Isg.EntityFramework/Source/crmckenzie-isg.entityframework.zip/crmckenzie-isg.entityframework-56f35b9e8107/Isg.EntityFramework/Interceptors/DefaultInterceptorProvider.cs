using System;
using System.Collections.Generic;

namespace Isg.EntityFramework.Interceptors
{
    public class DefaultInterceptorProvider : IInterceptorProvider
    {
        private readonly IInterceptor[] _interceptors;

        public IEnumerable<IInterceptor> GetInterceptors()
        {
            return Array.AsReadOnly(_interceptors);
        }

        public DefaultInterceptorProvider(params IInterceptor[] interceptors)
        {
            _interceptors = interceptors;
        }
    }
}