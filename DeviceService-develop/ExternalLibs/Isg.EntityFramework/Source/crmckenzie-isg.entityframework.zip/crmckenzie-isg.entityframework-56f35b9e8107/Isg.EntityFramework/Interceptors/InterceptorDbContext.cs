﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Isg.EntityFramework.Interceptors
{
    [Obsolete("Please inherit from Isg.EntityFramework.DbContextBase instead.")]
    public class InterceptorDbContext : DbContextBase
    {
    }
}
