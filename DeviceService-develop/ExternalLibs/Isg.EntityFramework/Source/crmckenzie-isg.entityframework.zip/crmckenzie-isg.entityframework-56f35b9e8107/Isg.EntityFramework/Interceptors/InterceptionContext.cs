using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Core.Objects;
using System.Data.Entity.Infrastructure;
using System.Linq;

namespace Isg.EntityFramework.Interceptors
{
    public class InterceptionContext
    {
        public DbContextBase DbContext { get; internal set; }
        public ObjectContext ObjectContext { get; internal set; }
        public ObjectStateManager ObjectStateManager { get; internal set; }
        public DbChangeTracker ChangeTracker { get; internal set; }
        public IEnumerable<DbEntityEntry> Entries { get; internal set; }
        public ILookup<EntityState, DbEntityEntry> EntriesByState { get; internal set; }

        public void Before()
        {
            var interceptors = InterceptorProvider.GetInterceptors().ToList();
            interceptors.ForEach(intercept => intercept.Before(this));
        }

        public void After()
        {
            var interceptors = InterceptorProvider.GetInterceptors().ToList();
            interceptors.ForEach(intercept => intercept.After(this));
        }

    }
}