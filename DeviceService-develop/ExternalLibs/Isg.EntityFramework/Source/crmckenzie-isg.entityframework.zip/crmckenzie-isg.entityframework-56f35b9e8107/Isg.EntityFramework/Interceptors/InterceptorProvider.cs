﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Isg.EntityFramework.Interceptors
{
    public static class InterceptorProvider
    {
        private static IInterceptorProvider _currentInterceptorProvider = new DefaultInterceptorProvider();

        public static IEnumerable<IInterceptor> GetInterceptors()
        {
            VerifyInterceptorProviderHasBeenSet();
            return _currentInterceptorProvider.GetInterceptors();
        }

        private static void VerifyInterceptorProviderHasBeenSet()
        {
            if (_currentInterceptorProvider == null)
                throw new InvalidOperationException("InterceptorProvider has not been set.");
        }

        public static void SetInterceptorProvider(IInterceptorProvider interceptorProvider)
        {
            _currentInterceptorProvider = interceptorProvider;
        }

    }
}
