using System.Collections.Generic;

namespace Isg.EntityFramework.Interceptors
{
    public interface IInterceptorProvider
    {
        IEnumerable<IInterceptor> GetInterceptors();
    }
}