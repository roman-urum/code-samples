using System;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;

namespace Isg.EntityFramework.Interceptors
{
    public class ChangeInterceptor<T> : TypeInterceptor
    {
        protected override void OnBefore(DbEntityEntry item, EntityState state, InterceptionContext context)
        {
            T tItem = (T)item.Entity;
            switch (state)
            {
                case EntityState.Added:
                    this.OnBeforeInsert(item, tItem, context);
                    break;
                case EntityState.Deleted:
                    this.OnBeforeDelete(item, tItem, context);
                    break;
                case EntityState.Modified:
                    this.OnBeforeUpdate(item, tItem, context);
                    break;
            }
        }

        protected override void OnAfter(DbEntityEntry item, EntityState state, InterceptionContext context)
        {
            T tItem = (T)item.Entity;
            switch (state)
            {
                case EntityState.Added:
                    this.OnAfterInsert(item, tItem, context);
                    break;
                case EntityState.Deleted:
                    this.OnAfterDelete(item, tItem, context);
                    break;
                case EntityState.Modified:
                    this.OnAfterUpdate(item, tItem, context);
                    break;
            }
        }

        protected virtual void OnBeforeInsert(DbEntityEntry entry, T item, InterceptionContext context)
        {
            OnBeforeInsert(entry, item);
        }

        protected virtual void OnAfterInsert(DbEntityEntry entry, T item, InterceptionContext context)
        {
            OnAfterInsert(entry, item);
        }

        protected virtual void OnBeforeUpdate(DbEntityEntry entry, T item, InterceptionContext context)
        {
            OnBeforeUpdate(entry, item);
        }

        protected virtual void OnAfterUpdate(DbEntityEntry entry, T item, InterceptionContext context)
        {
            OnAfterUpdate(entry, item);
        }

        protected virtual void OnBeforeDelete(DbEntityEntry entry, T item, InterceptionContext context)
        {
            OnBeforeDelete(entry, item);
        }

        protected virtual void OnAfterDelete(DbEntityEntry entry, T item, InterceptionContext context)
        {
            OnAfterDelete(entry, item);
        }



        [Obsolete("Use OnBeforeInsert(DbEntityEntry, T, InterceptionContext) instead.")]
        protected virtual void OnBeforeInsert(DbEntityEntry entry, T item)
        {
            return;
        }

        [Obsolete("Use OnAfterInsert(DbEntityEntry, T, InterceptionContext) instead.")]
        protected virtual void OnAfterInsert(DbEntityEntry entry, T item)
        {
            return;
        }

        [Obsolete("Use OnBeforeUpdate(DbEntityEntry, T, InterceptionContext) instead.")]
        protected virtual void OnBeforeUpdate(DbEntityEntry entry, T item)
        {
            return;
        }

        [Obsolete("Use OnAfterUpdate(DbEntityEntry, T, InterceptionContext) instead.")]
        protected virtual void OnAfterUpdate(DbEntityEntry entry, T item)
        {
            return;
        }

        [Obsolete("Use OnBeforeDelete(DbEntityEntry, T, InterceptionContext) instead.")]
        protected virtual void OnBeforeDelete(DbEntityEntry entry, T item)
        {
            return;
        }

        [Obsolete("Use OnAftereDelete(DbEntityEntry, T, InterceptionContext) instead.")]
        protected virtual void OnAfterDelete(DbEntityEntry entry, T item)
        {
            return;
        }


        protected ChangeInterceptor()
            : base(typeof(T))
        {

        }
    }
}