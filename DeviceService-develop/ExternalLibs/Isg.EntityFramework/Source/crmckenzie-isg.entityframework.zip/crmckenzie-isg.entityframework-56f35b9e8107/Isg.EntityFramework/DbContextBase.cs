using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Data.Entity;
using System.Data.Entity.Core.Objects;
using System.Data.Entity.Infrastructure;
using System.Data.Entity.ModelConfiguration;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Isg.EntityFramework.Interceptors;

namespace Isg.EntityFramework
{
    public class DbContextBase : DbContext
    {
        protected ObjectContext ObjectContext
        {
            get { return ((IObjectContextAdapter) this).ObjectContext; }
        }

        protected ObjectStateManager ObjectStateManager
        {
            get { return this.ObjectContext.ObjectStateManager; }
        }

        public override int SaveChanges()
        {
            var entries = base.ChangeTracker.Entries().ToList();

            var entriesByState = entries.ToLookup(row => row.State);
            var intercept = new InterceptionContext
                                {
                                    DbContext = this,
                                    ObjectContext = this.ObjectContext,
                                    ObjectStateManager = this.ObjectStateManager,
                                    ChangeTracker = base.ChangeTracker,
                                    Entries = entries,
                                    EntriesByState = entriesByState,
                                };

            intercept.Before();
            var result = base.SaveChanges();
            intercept.After();

            return result;
        }

        public override async Task<int> SaveChangesAsync()
        {
            var entries = base.ChangeTracker.Entries().ToList();

            var entriesByState = entries.ToLookup(row => row.State);
            var intercept = new InterceptionContext
            {
                DbContext = this,
                ObjectContext = this.ObjectContext,
                ObjectStateManager = this.ObjectStateManager,
                ChangeTracker = base.ChangeTracker,
                Entries = entries,
                EntriesByState = entriesByState,
            };

            intercept.Before();
            var result = await base.SaveChangesAsync();
            intercept.After();

            return result;
        }

        public void ExecuteSql(string sql, params object[] parameters)
        {
            ObjectContext.ExecuteStoreCommand(sql, parameters);
        }

        public ObjectResult<T> ExecuteQuery<T>(string sql, params object[] parameters)
        {
            return ObjectContext.ExecuteStoreQuery<T>(sql, parameters);
        }

        public int ExecuteStoredProcedure(string procedureName, params ObjectParameter[] parameters)
        {
            return ObjectContext.ExecuteFunction(procedureName, parameters);
        }

        public ObjectResult<T> ExecuteStoredProcedure<T>(string procedureName, params ObjectParameter[] parameters)
        {
            return ObjectContext.ExecuteFunction<T>(procedureName, parameters);
        }

        protected DbContextBase(string connectionString)
            : base(connectionString)
        {
        }

        public DbContextBase(): base()
        {
        }

        public DbContextBase(DbConnection dbConnection, bool contextOwnsConnection) : base(dbConnection, contextOwnsConnection)
        {
            
        }
    }

}