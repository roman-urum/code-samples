using System.Data.Entity;

namespace Isg.EntityFramework.Configuration
{
    public interface IModelConfiguration
    {
        void Configure(DbModelBuilder modelBuilder);
    }
}