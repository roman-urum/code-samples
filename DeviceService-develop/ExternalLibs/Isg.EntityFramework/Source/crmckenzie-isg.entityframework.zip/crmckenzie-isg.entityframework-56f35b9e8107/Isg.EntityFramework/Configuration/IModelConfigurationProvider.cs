﻿using System.Collections.Generic;

namespace Isg.EntityFramework.Configuration
{
    public interface IModelConfigurationProvider
    {
        IEnumerable<IModelConfiguration> Get();
    }
}
