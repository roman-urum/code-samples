﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.ModelConfiguration;
using System.Linq;
using System.Reflection;
using System.Text;

namespace Isg.EntityFramework.Configuration
{
    public class AssemblyScanEntityConfigurationType : IModelConfiguration
    {
        private readonly Assembly[] _configurationAssemblies;

        public void Configure(DbModelBuilder modelBuilder)
        {
            var types = GetConfigurationTypes();;

            var instances = types
                .Select(System.Activator.CreateInstance)
                .ToList();

            foreach (var instance in instances)
                modelBuilder.Configurations.Add((dynamic)instance);
        }

        public IEnumerable<Type> GetConfigurationTypes()
        {
            var types = from assembly in _configurationAssemblies
                        from type in assembly.GetTypes()
                        where !type.IsAbstract
                              && !type.IsInterface
                              && type.BaseType != null
                              && type.BaseType.IsGenericType
                              && type.BaseType.GetGenericTypeDefinition() == typeof (EntityTypeConfiguration<>)
                        select type;
            return types;
        }

        public AssemblyScanEntityConfigurationType(params Assembly[] configurationAssemblies)
        {
            _configurationAssemblies = configurationAssemblies;
        }
    }
}
