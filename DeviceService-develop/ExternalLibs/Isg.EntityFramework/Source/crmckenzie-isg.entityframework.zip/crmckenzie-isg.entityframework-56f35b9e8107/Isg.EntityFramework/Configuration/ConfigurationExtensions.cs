using System.ComponentModel.DataAnnotations;
using System.Data.Entity.ModelConfiguration.Configuration;

namespace Isg.EntityFramework.Configuration
{
    public static class ConfigurationExtensions
    {
        public static PrimitivePropertyConfiguration Identity(this PrimitivePropertyConfiguration primitiveProperty, bool isIdentity)
        {
            var option = isIdentity ? DatabaseGeneratedOption.Identity : DatabaseGeneratedOption.None;
            return primitiveProperty.HasDatabaseGeneratedOption(option);
        }

        public static PrimitivePropertyConfiguration Computed(this PrimitivePropertyConfiguration primitiveProperty)
        {
            return primitiveProperty.HasDatabaseGeneratedOption(DatabaseGeneratedOption.Computed);
        }
        
    }
}