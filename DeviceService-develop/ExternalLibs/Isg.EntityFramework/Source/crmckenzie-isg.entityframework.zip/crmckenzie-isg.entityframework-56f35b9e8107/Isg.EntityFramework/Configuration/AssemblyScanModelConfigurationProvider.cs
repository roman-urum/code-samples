using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Reflection;

namespace Isg.EntityFramework.Configuration
{
    public class AssemblyScanModelConfigurationProvider : IModelConfigurationProvider
    {
        private readonly AssemblyScanEntityConfigurationType _entityConfigurationType;

        public IEnumerable<IModelConfiguration> Get()
        {
            return new[] {_entityConfigurationType};
        }

        public AssemblyScanModelConfigurationProvider(params Assembly[] configurationAssemblies)
        {
            this._entityConfigurationType = new AssemblyScanEntityConfigurationType(configurationAssemblies);
        }
    }
}