using System;

namespace Isg.Domain
{
    public interface IAuditable
    {
        DateTime CreateDate { get; set; }
        string CreateUser { get; set; }

        DateTime UpdateDate { get; set; }
        string UpdateUser { get; set; }
    }
}