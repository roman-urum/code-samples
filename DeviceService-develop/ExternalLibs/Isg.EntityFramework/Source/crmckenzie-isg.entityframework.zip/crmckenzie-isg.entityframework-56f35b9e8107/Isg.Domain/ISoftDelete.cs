namespace Isg.Domain
{
    public interface ISoftDelete
    {
        bool IsDeleted { get; set; }
    }
}