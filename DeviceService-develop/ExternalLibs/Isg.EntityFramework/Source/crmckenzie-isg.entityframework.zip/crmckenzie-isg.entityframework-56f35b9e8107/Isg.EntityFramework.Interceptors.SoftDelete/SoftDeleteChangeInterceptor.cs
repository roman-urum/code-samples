using System;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using Isg.Domain;

namespace Isg.EntityFramework.Interceptors.SoftDelete
{
    public class SoftDeleteChangeInterceptor : ChangeInterceptor<ISoftDelete>
    {
        protected override void OnBeforeInsert(DbEntityEntry entry, ISoftDelete item, InterceptionContext context)
        {
            base.OnBeforeInsert(entry, item, context);
            item.IsDeleted = false;
        }

        protected override void OnBeforeDelete(DbEntityEntry entry, ISoftDelete item, InterceptionContext context)
        {
            if (item.IsDeleted)
                throw new InvalidOperationException("Item is already deleted.");

            base.OnBeforeDelete(entry, item, context);
            item.IsDeleted = true;
            entry.State = EntityState.Modified;
        }
    }
}