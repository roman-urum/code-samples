using System.Data.Entity;

namespace Isg.EntityFramework.ObservableProvider.TestModels
{
    /// <summary>
    /// Okay, so it's a pitiful Northwind DbContext, but it's enough to get started and prove concept.
    /// </summary>
    public class NorthwindDbContext : DbContext
    {
        public IDbSet<Category> Categories { get; set; } 

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder
                .Entity<Category>()
                .HasKey(c => c.CategoryId);
        }

        public NorthwindDbContext(string nameOrConnectionString) : base(nameOrConnectionString)
        {
        }

        public NorthwindDbContext()
        {
            
        }

    }
}