using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;

namespace Isg.Specification
{
    public abstract class CompositeSpecification<T> : Specification<T>
    {
        public override Expression<Func<T, bool>> IsSatisfied()
        {
            var expressions = GetExpressions().ToArray();

            if (expressions.Length == 0)
                return p => true;

            if (expressions.Length == 1)
                return Negate ? expressions.Single().Not() : expressions.Single();

            var result = expressions.Aggregate((left, right) => left.And(right));

            if (Negate)
                result = result.Not();

            return result;
        }

        /// <summary>
        /// Causes the entire expression to be evaluated in the negative.
        /// </summary>
        public bool Negate { get; set; }

        protected abstract IEnumerable<Expression<Func<T, bool>>> GetExpressions();
    }
}