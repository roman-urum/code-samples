using System;
using System.Linq.Expressions;

namespace Isg.Specification
{
    /// <summary>
    /// 
    /// </summary>
    /// <typeparam name="T"></typeparam>
    /// <remarks>
    /// Gratefully stolen from http://blogs.msdn.com/b/meek/archive/2008/05/02/linq-to-entities-combining-predicates.aspx
    /// and http://davedewinter.com/2009/05/31/linq-expression-trees-and-the-specification-pattern/
    /// </remarks>
    public abstract class Specification<T> : ISpecification<T>
    {
        public abstract Expression<Func<T, bool>> IsSatisfied();
    }
}