using System;
using System.Linq.Expressions;

namespace Isg.Specification
{
    public interface ISpecification<T>
    {
        Expression<Func<T, bool>> IsSatisfied();
    }
}