﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Isg.EntityFramework.ObservableProvider;
using Isg.EntityFramework.ObservableProvider.TestModels;
using NUnit.Framework;

namespace Isg.EntityFramework.Observable.AppConfig.Tests
{
    [TestFixture]
    public class DataAccessTests
    {
        [TestFixtureSetUp]
        public void BeforeAnyTestRuns()
        {
            ObservableProviderConfiguration.RegisterProvider("System.Data.SqlServerCe.4.0", setAsDefault:false);
            Database.SetInitializer(new DropCreateDatabaseIfModelChanges<NorthwindDbContext>());
        }

        [Test]
        public void InsertCategory()
        {
            var eventFired = false;

            Hub.CommandExecuting += (sender, args) =>
                {
                    eventFired = true;
                };

            using (var context = new NorthwindDbContext())
            {
                var newRecord = new Category()
                {
                    CategoryName = Guid.NewGuid().ToString()
                };

                context.Categories.Add(newRecord);
                context.SaveChanges();

                var categories = context.Set<Category>().ToList();
                foreach (var category in categories)
                    Console.WriteLine(category.CategoryName);
            }


            Assert.That(eventFired, Is.True);
        }
    }
}
