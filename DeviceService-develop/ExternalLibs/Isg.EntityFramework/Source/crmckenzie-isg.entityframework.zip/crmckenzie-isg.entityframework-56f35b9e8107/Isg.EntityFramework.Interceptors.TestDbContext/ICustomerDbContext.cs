using System.Data.Entity;

namespace Isg.EntityFramework.Interceptors.TestDbContext
{
    public interface ICustomerDbContext
    {
        IDbSet<Invoice> Invoices { get; set; }
        IDbSet<Customer> Customers { get; set; }
        int SaveChanges();
    }
}