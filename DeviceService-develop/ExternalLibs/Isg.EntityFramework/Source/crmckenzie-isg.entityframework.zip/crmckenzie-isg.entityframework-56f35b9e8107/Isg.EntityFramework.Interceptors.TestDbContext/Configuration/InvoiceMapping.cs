﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.ModelConfiguration;
using System.Linq;
using System.Text;

namespace Isg.EntityFramework.Interceptors.TestDbContext.Configuration
{
    public class InvoiceMapping : EntityTypeConfiguration<Invoice>
    {
        public InvoiceMapping()
        {
            HasKey(i => i.InvoiceId);

            HasRequired(invoice => invoice.Customer)
                .WithMany(customer => customer.Invoices)
                .HasForeignKey(i => i.CustomerId)
                ;           
        }
    }
}
