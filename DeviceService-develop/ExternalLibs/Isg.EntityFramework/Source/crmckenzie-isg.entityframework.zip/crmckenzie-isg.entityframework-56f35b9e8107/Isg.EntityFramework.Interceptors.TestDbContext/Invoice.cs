﻿using System;
using Isg.Domain;
using Isg.EntityFramework.Interceptors.SoftDelete;

namespace Isg.EntityFramework.Interceptors.TestDbContext
{
    public class Invoice : ISoftDelete
    {
        public int InvoiceId { get; set; }
        public string Number { get; set; }

        public int CustomerId { get; set; }
        public virtual Customer Customer { get; set; }

        public bool IsDeleted { get; set; }

        public DateTime? Shipped { get; set; }
    }

    
}
