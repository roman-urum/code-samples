﻿using System.Data.Entity;

namespace Isg.EntityFramework.Interceptors.TestDbContext
{
    public class CustomerDbContext : DbContextBase, ICustomerDbContext
    {
        public IDbSet<Invoice> Invoices { get; set; }
        public IDbSet<Customer> Customers { get; set; }
    }
}
