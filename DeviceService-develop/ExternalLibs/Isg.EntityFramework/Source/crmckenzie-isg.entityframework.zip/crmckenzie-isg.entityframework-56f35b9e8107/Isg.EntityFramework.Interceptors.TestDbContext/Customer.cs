using System;
using System.Collections.Generic;
using Isg.Domain;
using Isg.EntityFramework.Interceptors.SoftDelete;

namespace Isg.EntityFramework.Interceptors.TestDbContext
{
    public class Customer : ISoftDelete, IAuditable
    {
        public int CustomerId { get; set; }
        public string Name { get; set; }
        public string Contact { get; set; }
        public virtual ICollection<Invoice> Invoices { get; set; }

        public bool IsDeleted { get; set; }

        public virtual DateTime CreateDate { get; set; }
        public virtual string CreateUser { get; set; }
        public virtual DateTime UpdateDate { get; set; }
        public virtual string UpdateUser { get; set; }
    }
}