﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using Isg.Specification;

namespace Isg.EntityFramework.Interceptors.TestDbContext.Specifications
{
    public class CustomerSpecification : CompositeSpecification<Customer>
    {
        public string Name { get; set; }
        public bool? HasInvoices { get; set; }

        protected override IEnumerable<Expression<Func<Customer, bool>>> GetExpressions()
        {
            if (!string.IsNullOrWhiteSpace(Name))
                yield return ByName();

            if (HasInvoices.HasValue)
                yield return ByHasInvoices();
        }

        private Expression<Func<Customer, bool>> ByHasInvoices()
        {
            if (HasInvoices.Value)
                return c => c.Invoices.Any();
            return c => !c.Invoices.Any();
        }

        private Expression<Func<Customer, bool>> ByName()
        {
            return c => c.Name.StartsWith(Name);
        }
    }
}
