param(
	[parameter(Mandatory = $true)][string] $apiKey
)

$cmd = "nuget setApiKey ""$apiKey""";
$cmd
Invoke-Expression $cmd

$packages = Get-ChildItem -filter "*.nupkg"

if ($packages-ne $null)
{
	$packages | ForEach-Object {
		$file = $_.Name
		"Publishing package $file"

		$cmd = "nuget push $file"
		$cmd
		Invoke-Expression $cmd
	}
}

