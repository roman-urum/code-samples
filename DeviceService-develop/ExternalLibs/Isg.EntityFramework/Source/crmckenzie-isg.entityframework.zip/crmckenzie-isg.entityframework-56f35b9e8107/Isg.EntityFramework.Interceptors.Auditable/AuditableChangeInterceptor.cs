﻿using System.Data.Entity.Infrastructure;
using System.Security.Principal;
using Isg.Domain;

namespace Isg.EntityFramework.Interceptors.Auditable
{
    public class AuditableChangeInterceptor : ChangeInterceptor<IAuditable>
    {
        private readonly IPrincipal _principal;
        private readonly IClock _clock;


        protected override void OnBeforeInsert(DbEntityEntry entry, IAuditable item, InterceptionContext context)
        {
            item.CreateDate = _clock.Now;
            item.CreateUser = _principal.Identity.Name;
            item.UpdateDate = _clock.Now;
            item.UpdateUser = _principal.Identity.Name;

            base.OnBeforeInsert(entry, item, context);
        }

        protected override void OnBeforeUpdate(DbEntityEntry entry, IAuditable item, InterceptionContext context)
        {
           item.UpdateDate = _clock.Now;
           item.UpdateUser = _principal.Identity.Name;
            base.OnBeforeUpdate(entry, item, context);
        }

        public AuditableChangeInterceptor(IPrincipal principal, IClock clock)
        {
            _principal = principal;
            _clock = clock;
        }
    }
}
