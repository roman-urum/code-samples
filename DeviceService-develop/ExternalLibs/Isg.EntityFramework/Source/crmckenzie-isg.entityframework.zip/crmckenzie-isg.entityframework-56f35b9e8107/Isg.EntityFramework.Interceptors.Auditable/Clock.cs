﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Isg.EntityFramework.Interceptors.Auditable
{
    public class Clock : IClock
    {
        public DateTime Now { get { return DateTime.Now; } }
        public DateTime Today { get { return DateTime.Today; } }
    }
}
