using System;

namespace Isg.EntityFramework.Interceptors.Auditable
{
    public interface IClock
    {
        DateTime Now { get; }
        DateTime Today { get; }
    }
}