﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Isg.EntityFramework.Interceptors.TestDbContext;
using Isg.EntityFramework.Interceptors.TestDbContext.Specifications;
using NUnit.Framework;

namespace Isg.Specification.Tests
{
    [TestFixture]
    public class CustomerSpecificationTests
    {
        [TestFixtureSetUp]
        public void BeforeAnyTest()
        {
            using (var db = new CustomerDbContext())
            {
                if (db.Database.Exists())
                    db.Database.Delete();

                db.Database.Create();

                var customerWithInvoices = new Customer()
                                               {
                                                   Name = "Dagny Taggart",
                                                   CreateDate = DateTime.Now,
                                                   CreateUser = "Foo",
                                                   UpdateDate = DateTime.Now,
                                                   UpdateUser = "Bar",
                                               };

                var invoice = new Invoice()
                                  {
                                      Customer = customerWithInvoices,
                                      Number = "Sept-02-1957",
                                  };

                var customerWithoutInvoices = new Customer()
                                                  {
                                                      Name = "John Galt",
                                                      CreateDate = DateTime.Now,
                                                      CreateUser = "Foo",
                                                      UpdateDate = DateTime.Now,
                                                      UpdateUser = "Bar",
                                                  };

                db.Customers.Add(customerWithInvoices);
                db.Customers.Add(customerWithoutInvoices);
                db.Invoices.Add(invoice);

                db.SaveChanges();
            }
        }

        [Test]
        public void NoFilters()
        {
            // Arrange
            var filter = new CustomerSpecification();

            // Act
            using (var context = new CustomerDbContext())
            {
                var query = context.Customers
                    .Where(filter.IsSatisfied())
                    .ToList();

                // Assert
                Assert.That(query, Has.Count.EqualTo(2));
            }

        }

        [Test]
        public void StartsWithName()
        {
            // Arrange
            var filter = new CustomerSpecification()
                             {
                                 Name = "Dag",
                             };

            // Act
            using (var context = new CustomerDbContext())
            {
                var query = context.Customers
                    .Where(filter.IsSatisfied())
                    .ToList();

                // Assert
                Assert.That(query, Has.Count.EqualTo(1));
                var result = query.Single();
                Assert.That(result.Name, Is.EqualTo("Dagny Taggart"));
            }
        }

        [Test]
        public void NotStartsWithName()
        {
            // Arrange
            var filter = new CustomerSpecification()
            {
                Name = "Dag",
                Negate = true,
            };

            // Act
            using (var context = new CustomerDbContext())
            {
                var query = context.Customers
                    .Where(filter.IsSatisfied())
                    .ToList();

                // Assert
                Assert.That(query, Has.Count.EqualTo(1));
                var result = query.Single();
                Assert.That(result.Name, Is.EqualTo("John Galt"));
            }
        }

        [Test]
        public void HasInvoices()
        {
            // Arrange
            var filter = new CustomerSpecification()
                             {
                                 HasInvoices = true,
                             };

            // Act
            using (var context = new CustomerDbContext())
            {
                var query = context.Customers
                    .Where(filter.IsSatisfied())
                    .ToList();

                // Assert
                Assert.That(query, Has.Count.EqualTo(1));
                var result = query.Single();
                Assert.That(result.Name, Is.EqualTo("Dagny Taggart"));
            }
        }

        [Test]
        public void NotHasInvoices()
        {
            // Arrange
            var filter = new CustomerSpecification()
            {
                HasInvoices = false,
            };

            // Act
            using (var context = new CustomerDbContext())
            {
                var query = context.Customers
                    .Where(filter.IsSatisfied())
                    .ToList();

                // Assert
                Assert.That(query, Has.Count.EqualTo(1));
                var result = query.Single();
                Assert.That(result.Name, Is.EqualTo("John Galt"));
            }
        }

    }
}
