﻿// Copyright (c) Microsoft Corporation.  All rights reserved.

using System;
using System.Data.Common;
using System.Data.Entity.Core.Common.CommandTrees;
using System.Globalization;
using System.Text;

namespace Isg.EntityFramework.ObservableProvider
{
    /// <summary>
    /// Arguments to <see cref="ObservableDbConnection.CommandExecuting" />, <see cref="ObservableDbConnection.CommandFinished" /> 
    /// and <see cref="ObservableDbConnection.CommandFailed" /> events.
    /// </summary>
    public class CommandExecutionEventArgs : EventArgs
    {
        /// <summary>
        /// Initializes a new instance of the CommandExecutionEventArgs class.
        /// </summary>
        /// <param name="dbCommand">The dbCommand.</param>
        /// <param name="method">The method.</param>
        internal CommandExecutionEventArgs(ObservableDbCommand dbCommand, string method)
        {
            this.CommandId = dbCommand.CommandId;
            this.Command = dbCommand;
            this.CommandTree = dbCommand.Definition.CommandTree;
            this.Method = method;
        }

        /// <summary>
        /// Gets the dbCommand ID.
        /// </summary>
        /// <value>The dbCommand ID.</value>
        public int CommandId { get; private set; }

        /// <summary>
        /// Gets the dbCommand object.
        /// </summary>
        /// <value>The dbCommand.</value>
        public DbCommand Command { get; private set; }

        /// <summary>
        /// Gets the dbCommand tree.
        /// </summary>
        /// <value>The dbCommand tree.</value>
        public DbCommandTree CommandTree { get; private set; }

        /// <summary>
        /// Gets the method which caused dbCommand execution (ExecuteScalar, ExecuteQuery, ExecuteNonQuery).
        /// </summary>
        /// <value>The method name.</value>
        public string Method { get; private set; }

        /// <summary>
        /// Gets the execution status.
        /// </summary>
        /// <value>Execution status.</value>
        public CommandExecutionStatus Status { get; internal set; }

        /// <summary>
        /// Gets the dbCommand result.
        /// </summary>
        /// <value>The dbCommand result.</value>
        public object Result { get; internal set; }

        /// <summary>
        /// Gets the time it took to execute the dbCommand.
        /// </summary>
        /// <value>The duration.</value>
        public TimeSpan Duration { get; internal set; }

        public Exception Error { get; set; }

        /// <summary>
        /// Returns textual dump of the dbCommand suitable for putting in a log file.
        /// </summary>
        /// <returns>Textual dump of the dbCommand including dbCommand text and parameters, 
        /// suitable for putting in a log file.</returns>
        public string ToTraceString()
        {
            var sb = new StringBuilder();
            sb.Append(this.Command.CommandText);

            foreach (DbParameter par in this.Command.Parameters)
            {
                sb.AppendFormat(
                    CultureInfo.InvariantCulture,
                    "\r\n-- {0} (dbtype={1}, size={4}, direction={2}) = {3}", 
                    par.ParameterName, 
                    par.DbType, 
                    par.Direction, 
                    GetValueText(par.Value), 
                    par.Size);
            }

            return sb.ToString();
        }

        private static string GetValueText(object value)
        {
            if (value == null || value is DBNull)
            {
                return "null";
            }
            else if (value is string)
            {
                return "\"" + value + "\"";
            }
            else
            {
                return value.ToString();
            }
        }
    }
}
