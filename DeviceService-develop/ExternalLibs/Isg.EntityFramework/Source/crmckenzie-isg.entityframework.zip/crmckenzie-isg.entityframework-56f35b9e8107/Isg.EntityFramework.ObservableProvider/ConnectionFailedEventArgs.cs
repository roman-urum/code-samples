using System;
using System.Data;

namespace Isg.EntityFramework.ObservableProvider
{
    public class ConnectionFailedEventArgs : ConnectionEventArgs
    {
        public Exception Exception { get; private set; }

        public ConnectionFailedEventArgs(IDbConnection connection, Exception exception) : base(connection)
        {
            Exception = exception;
        }
    }
}