// Copyright (c) Microsoft Corporation.  All rights reserved.

using System;
using System.Data.Common;
using System.Data.Entity.Core.Common;

namespace Isg.EntityFramework.ObservableProvider
{
    public class ObservableDbProviderFactory : DbProviderFactory, IServiceProvider
    {
        /// <summary>
        /// Gets or sets the singleton instance of the provider.
        /// </summary>
        /// <value>The instance.</value>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Security",
            "CA2104:DoNotDeclareReadOnlyMutableReferenceTypes", Justification = "Factory is immutale.")] 
        public static readonly ObservableDbProviderFactory Instance = new ObservableDbProviderFactory();

        public static readonly ObservableDbConnectionFactory ConnectionFactory = new ObservableDbConnectionFactory();

        private readonly ObservableDbProviderServices _services;

        /// <summary>
        /// Initializes a new instance of the ObservableDbProviderFactory class.
        /// </summary>
        public ObservableDbProviderFactory() : base()
        {
            this._services = new ObservableDbProviderServices();
        }

        /// <summary>
        /// Returns a new instance of the provider's class that implements the <see cref="T:System.Data.Common.DbConnection"/> class.
        /// </summary>
        /// <returns>
        /// A new instance of <see cref="T:System.Data.Common.DbConnection"/>.
        /// </returns>
        public override DbConnection CreateConnection()
        {
            return ConnectionFactory.CreateConnection(string.Empty);
        }

        /// <summary>
        /// Gets the service object of the specified type.
        /// </summary>
        /// <param name="serviceType">An object that specifies the type of service object to get.</param>
        /// <returns>
        /// A service object of type <paramref name="serviceType"/>.
        /// -or-
        /// null if there is no service object of type <paramref name="serviceType"/>.
        /// </returns>
        public object GetService(Type serviceType)
        {
            if (serviceType == typeof(DbProviderServices))
            {
                return this._services;
            }
            else
            {
                return null;
            }
        }

    }
}
