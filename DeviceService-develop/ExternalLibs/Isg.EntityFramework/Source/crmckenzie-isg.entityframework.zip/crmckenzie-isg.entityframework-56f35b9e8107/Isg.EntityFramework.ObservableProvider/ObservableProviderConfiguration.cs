﻿// Copyright (c) Microsoft Corporation.  All rights reserved.

using System;
using System.Configuration;
using System.Data;
using System.Data.Entity;
using System.Diagnostics.Contracts;

namespace Isg.EntityFramework.ObservableProvider
{
    public static class ObservableProviderConfiguration
    {
        private const string ProviderName = "Observable Provider";
        public const string ProviderInvariantName = "ObservableProvider";

        /// <summary>
        /// Gets or sets the default wrapped provider.
        /// </summary>
        /// <value>The default wrapped provider.</value>
        internal static string WrappedProvider { get; set; }

        /// <summary>
        /// Registers the provider factory 
        /// </summary>
        public static void RegisterProvider(string wrappedProviderName, bool setAsDefault = true)
        {
            Contract.Requires(!string.IsNullOrWhiteSpace(wrappedProviderName));

            WrappedProvider = wrappedProviderName;

            var data = (DataSet)ConfigurationManager.GetSection("system.data");
            var providerFactories = data.Tables["DbProviderFactories"];
            providerFactories.Rows.Add(ProviderName, ProviderName, ProviderInvariantName, typeof(ObservableDbProviderFactory).AssemblyQualifiedName);

            if (setAsDefault)
                Database.DefaultConnectionFactory = new ObservableDbConnectionFactory();
        }

    }
}
