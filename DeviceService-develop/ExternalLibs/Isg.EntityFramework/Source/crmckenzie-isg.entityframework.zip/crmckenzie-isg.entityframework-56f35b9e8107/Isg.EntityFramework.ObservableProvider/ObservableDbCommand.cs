// Copyright (c) Microsoft Corporation.  All rights reserved.

using System;
using System.Data;
using System.Data.Common;
using System.Diagnostics;
using System.Threading;
using Isg.EntityFramework.ObservableProvider.Internals;

namespace Isg.EntityFramework.ObservableProvider
{
    /// <summary>
    /// Implementation of <see cref="DbCommand"/> which traces all commands executed.
    /// </summary>
    internal class ObservableDbCommand : DbCommandWrapper
    {
        private static int globalCommandID;

        /// <summary>
        /// Initializes a new instance of the ObservableDbCommand class.
        /// </summary>
        /// <param name="wrappedCommand">The wrapped command.</param>
        /// <param name="commandDefinition">The command definition.</param>
        public ObservableDbCommand(DbCommand wrappedCommand, ObservableDbCommandDefinitionWrapper commandDefinition)
            : base(wrappedCommand, commandDefinition)
        {
            this.CommandId = Interlocked.Increment(ref globalCommandID);
        }

        /// <summary>
        /// Gets the unique command ID.
        /// </summary>
        /// <value>The command ID.</value>
        public int CommandId { get; private set; }

        /// <summary>
        /// Executes the query and returns the first column of the first row in the result set returned by the query. All other columns and rows are ignored.
        /// </summary>
        /// <returns>
        /// The first column of the first row in the result set.
        /// </returns>
        public override object ExecuteScalar()
        {
            var e = new CommandExecutionEventArgs(this, "ExecuteScalar") {Status = CommandExecutionStatus.Executing};
            this.RaiseExecuting(e);
            var sw = new Stopwatch();
            try
            {
                sw.Start();
                object result = base.ExecuteScalar();
                sw.Stop();
                e.Result = result;
                e.Duration = sw.Elapsed;
                e.Status = CommandExecutionStatus.Finished;
                this.RaiseFinished(e);
                return result;
            }
            catch (Exception ex)
            {
                e.Result = ex;
                e.Status = CommandExecutionStatus.Failed;
                this.RaiseFailed(e);
                throw;
            }
        }

        /// <summary>
        /// Executes a SQL statement against a connection object.
        /// </summary>
        /// <returns>The number of rows affected.</returns>
        public override int ExecuteNonQuery()
        {
            var e = new CommandExecutionEventArgs(this, "ExecuteNonQuery");
            e.Status = CommandExecutionStatus.Executing;
            var sw = new Stopwatch();
            this.RaiseExecuting(e);
            try
            {
                sw.Start();
                int result = base.ExecuteNonQuery();
                sw.Stop();
                e.Result = result;
                e.Duration = sw.Elapsed;
                e.Status = CommandExecutionStatus.Finished;
                this.RaiseFinished(e);
                return result;
            }
            catch (Exception ex)
            {
                e.Result = ex;
                e.Status = CommandExecutionStatus.Failed;
                this.RaiseFailed(e);
                throw;
            }
        }

        /// <summary>
        /// Executes the command text against the connection.
        /// </summary>
        /// <param name="behavior">An instance of <see cref="T:System.Data.CommandBehavior"/>.</param>
        /// <returns>
        /// A <see cref="T:System.Data.Common.DbDataReader"/>.
        /// </returns>
        protected override DbDataReader ExecuteDbDataReader(CommandBehavior behavior)
        {
            var e = new CommandExecutionEventArgs(this, "ExecuteReader");
            e.Status = CommandExecutionStatus.Executing;
            this.RaiseExecuting(e);
            try
            {
                var sw = new Stopwatch();
                sw.Start();
                DbDataReader result = base.ExecuteDbDataReader(behavior);
                sw.Stop();
                e.Result = result;
                e.Status = CommandExecutionStatus.Finished;
                e.Duration = sw.Elapsed;
                this.RaiseFinished(e);
                return result;
            }
            catch (Exception ex)
            {
                e.Error = ex;
                e.Status = CommandExecutionStatus.Failed;
                this.RaiseFailed(e);
                throw;
            }
        }

        /// <summary>
        /// Occurs when database command is executing.
        /// </summary>
        public event EventHandler<CommandExecutionEventArgs> Executing;

        /// <summary>
        /// Occurs when database command has finished execution.
        /// </summary>
        public event EventHandler<CommandExecutionEventArgs> Completed;

        /// <summary>
        /// Occurs when database command execution has failed.
        /// </summary>
        public event EventHandler<CommandExecutionEventArgs> Failed;

        internal void RaiseFailed(CommandExecutionEventArgs e)
        {
            if (Failed != null)
                Failed(this, e);
            global::Isg.EntityFramework.ObservableProvider.Hub.RaiseCommandFailed(this, e);
        }

        internal void RaiseExecuting(CommandExecutionEventArgs e)
        {
            if (Executing != null) 
                Executing(this, e);
            global::Isg.EntityFramework.ObservableProvider.Hub.RaiseCommandExecuting(this, e);
        }

        internal void RaiseFinished(CommandExecutionEventArgs e)
        {
            if (Completed != null)
                Completed(this, e);
            global::Isg.EntityFramework.ObservableProvider.Hub.RaiseCommandFinished(this, e);
        }

    }
}
