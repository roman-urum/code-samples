﻿using System;

namespace Isg.EntityFramework.ObservableProvider
{
    public static class Hub
    {
        /// <summary>
        /// Occurs when database command is executing.
        /// </summary>
        public static event EventHandler<CommandExecutionEventArgs> CommandExecuting;

        /// <summary>
        /// Occurs when database command has finished execution.
        /// </summary>
        public static event EventHandler<CommandExecutionEventArgs> CommandCompleted;

        /// <summary>
        /// Occurs when database command execution has failed.
        /// </summary>
        public static event EventHandler<CommandExecutionEventArgs> CommandFailed;

        public static event EventHandler<ConnectionEventArgs> ConnectionOpening;
        public static event EventHandler<ConnectionEventArgs> ConnectionOpened;

        public static event EventHandler<ConnectionFailedEventArgs> ConnectionFailed;

        public static event EventHandler<ConnectionEventArgs> ConnectionClosing;
        public static event EventHandler<ConnectionEventArgs> ConnectionClosed;

        internal static void RaiseConnectionOpening(object sender, ConnectionEventArgs e)
        {
            if (ConnectionOpening != null)
                ConnectionOpening(sender, e);
        }

        internal static void RaiseConnectionOpened(object sender, ConnectionEventArgs e)
        {
            if (ConnectionOpened != null)
                ConnectionOpened(sender, e);
        }

        internal static void RaiseConnectionFailed(object sender, ConnectionFailedEventArgs e)
        {
            if (ConnectionFailed != null)
                ConnectionFailed(sender, e);
        }

        internal static void RaiseConnectionClosing(object sender, ConnectionEventArgs e)
        {
            if (ConnectionClosing != null)
                ConnectionClosing(sender, e);
        }

        internal static void RaiseConnectionClosed(object sender, ConnectionEventArgs e)
        {
            if (ConnectionClosed != null)
                ConnectionClosed(sender, e);
        }


        internal static void RaiseCommandFailed(object sender, CommandExecutionEventArgs e)
        {
            if (CommandFailed != null)
                CommandFailed(sender, e);
        }

        internal static void RaiseCommandExecuting(object sender, CommandExecutionEventArgs e)
        {
            if (CommandExecuting != null)
                CommandExecuting(sender, e);
        }

        internal static void RaiseCommandFinished(object sender, CommandExecutionEventArgs e)
        {
            if (CommandCompleted != null)
                CommandCompleted(sender, e);
        }
    }
}
