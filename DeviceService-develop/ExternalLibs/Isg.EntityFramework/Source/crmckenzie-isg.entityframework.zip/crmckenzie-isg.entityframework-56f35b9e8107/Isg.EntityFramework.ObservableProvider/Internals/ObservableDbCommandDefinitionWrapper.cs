// Copyright (c) Microsoft Corporation.  All rights reserved.

using System.Data.Common;
using System.Data.Entity.Core.Common;
using System.Data.Entity.Core.Common.CommandTrees;

namespace Isg.EntityFramework.ObservableProvider.Internals
{
    /// <summary>
    /// Implementation of common methods of <see cref="DbCommandDefinition"/> class.
    /// </summary>
    public class ObservableDbCommandDefinitionWrapper : DbCommandDefinition
    {
        private readonly DbCommandDefinition _wrappedCommandDefinition;
        private readonly DbCommandTree _commandTree;

        public ObservableDbCommandDefinitionWrapper(DbCommandDefinition wrappedCommandDefinition, DbCommandTree commandTree)
        {
            this._wrappedCommandDefinition = wrappedCommandDefinition;
            this._commandTree = commandTree;
        }

        /// <summary>
        /// Gets the command tree.
        /// </summary>
        /// <value>The command tree.</value>
        public DbCommandTree CommandTree
        {
            get { return this._commandTree; }
        }

        /// <summary>
        /// Gets the wrapped command definition.
        /// </summary>
        /// <value>The wrapped command definition.</value>
        protected DbCommandDefinition WrappedCommandDefinition
        {
            get { return this._wrappedCommandDefinition; }
        }

        /// <summary>
        /// Creates and returns a <see cref="T:System.Data.Common.DbCommandDefinition"/> object associated with the current connection.
        /// </summary>
        /// <returns>
        /// A <see cref="T:System.Data.Common.DbCommandDefinition"/>.
        /// </returns>
        public override DbCommand CreateCommand()
        {
            var wrappedCommand = this._wrappedCommandDefinition.CreateCommand();
            var wrapper = new ObservableDbCommand(wrappedCommand, this);
            return wrapper;
        }
    }
}
