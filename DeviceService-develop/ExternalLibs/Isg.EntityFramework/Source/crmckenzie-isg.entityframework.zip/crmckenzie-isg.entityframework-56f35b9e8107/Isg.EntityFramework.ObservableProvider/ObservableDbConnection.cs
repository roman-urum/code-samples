// Copyright (c) Microsoft Corporation.  All rights reserved.

using System;
using System.Data.Common;
using Isg.EntityFramework.ObservableProvider.Internals;

namespace Isg.EntityFramework.ObservableProvider
{
    /// <summary>
    /// Wrapper <see cref="DbConnection"/> which traces all executed commands.
    /// </summary>
    public class ObservableDbConnection : DbConnectionWrapper
    {
        public event EventHandler<ConnectionEventArgs> Opening;
        public event EventHandler<ConnectionEventArgs> Opened;

        public event EventHandler<ConnectionFailedEventArgs> Failed;

        public event EventHandler<ConnectionEventArgs> Closing;
        public event EventHandler<ConnectionEventArgs> Closed; 

        /// <summary>
        /// Initializes a new instance of the ObservableDbConnection class.
        /// </summary>
        /// <param name="wrappedConnection">The wrapped connection.</param>
        public ObservableDbConnection(DbConnection wrappedConnection)
        {
            this.WrappedConnection = wrappedConnection;
        }


        /// <summary>
        /// Gets the <see cref="T:System.Data.Common.DbProviderFactory"/> for this <see cref="T:System.Data.Common.DbConnection"/>.
        /// </summary>
        /// <value></value>
        /// <returns>
        /// A <see cref="T:System.Data.Common.DbProviderFactory"/>.
        /// </returns>
        protected override DbProviderFactory DbProviderFactory
        {
            get
            {
                return ObservableDbProviderFactory.Instance;
            }
        }

        /// <summary>
        /// Gets the name of the default wrapped provider.
        /// </summary>
        /// <returns>Name of the default wrapped provider.</returns>
        public override string WrappedProviderName
        {
            get
            {
                return ObservableProviderConfiguration.WrappedProvider;
            }
        }

        public override void Open()
        {
            OnConnectionOpening();
            try
            {
                base.Open();
                OnConnectionOpened();

            }
            catch (Exception e)
            {
                OnConnectionFailed(e);   
                throw;
            }
        }

        private void OnConnectionFailed(Exception exception)
        {
            var e = new ConnectionFailedEventArgs(this, exception);
            if (Failed != null)
                Failed(this, e);

            Hub.RaiseConnectionFailed(this, e);
        }

        private void OnConnectionOpened()
        {
            var e = new ConnectionEventArgs(this);
            if (Opened != null)
                Opened(this, e);

            Hub.RaiseConnectionOpened(this, e); 
        }

        private void OnConnectionOpening()
        {
            var e = new ConnectionEventArgs(this);
            if (Opening != null)
                Opening(this, e);

            Hub.RaiseConnectionOpening(this, e);
        }

        public override void Close()
        {
            OnConnectionClosing();
            base.Close();
            OnConnectionClosed();
        }

        private void OnConnectionClosed()
        {
            var e = new ConnectionEventArgs(this);
            if (Closed != null)
                Closed(this, e);

            Hub.RaiseConnectionClosed(this, e);
        }

        private void OnConnectionClosing()
        {
            var e = new ConnectionEventArgs(this);
            if (Closing != null)
                Closing(this, e);

            Hub.RaiseConnectionClosing(this, e);
        }
    }
}
