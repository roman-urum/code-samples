using System.Data.Common;
using System.Data.Entity.Infrastructure;
using System.Diagnostics.Contracts;

namespace Isg.EntityFramework.ObservableProvider
{
    public class ObservableDbConnectionFactory : IDbConnectionFactory
    {
        public DbConnection CreateConnection(string nameOrConnectionString)
        {
            var factory = DbProviderFactories.GetFactory(ObservableProviderConfiguration.WrappedProvider);
            var wrappedConnection = factory.CreateConnection();
            var connectionString = GetConnectionString(nameOrConnectionString);

            if (!string.IsNullOrWhiteSpace(connectionString))
                wrappedConnection.ConnectionString = connectionString;                

            var result = new ObservableDbConnection(wrappedConnection);
            return result;
       
        }

        private static string GetConnectionString(string nameOrConnectionString)
        {
            var connectionStringSetting = System.Configuration.ConfigurationManager.ConnectionStrings[nameOrConnectionString];
            if (connectionStringSetting == null)
                return nameOrConnectionString;

            return connectionStringSetting.ConnectionString;
        }
    }
}