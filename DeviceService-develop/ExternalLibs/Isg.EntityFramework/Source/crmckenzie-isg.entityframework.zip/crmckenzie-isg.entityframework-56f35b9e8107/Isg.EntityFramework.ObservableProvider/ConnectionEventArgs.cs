using System;
using System.Data;

namespace Isg.EntityFramework.ObservableProvider
{
    public class ConnectionEventArgs : EventArgs
    {
        public IDbConnection Connection { get; set; }

        public ConnectionEventArgs(IDbConnection connection)
        {
            Connection = connection;
        }
    }
}