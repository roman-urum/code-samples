param(
	[parameter(Mandatory=$true)][string] $version,
	[bool] $deleteExistingPackages = $true
)

.\Install-VSCommandPrompt.ps1

if ($deleteExistingPackages -eq $true)
{
	$packages = Get-ChildItem -filter "*.nupkg"
	if ($packages -ne $null)
	{
		$packages | ForEach-Object { 
			$file = $_.Name
			"Deleting package $file"
			del $_ 
		}
	}
}


msbuild /target:clean
msbuild /p:Configuration=Release

$cmd = "nuget pack Isg.EntityFramework.Interceptors.nuspec -version $version"
$cmd
Invoke-Expression $cmd

$cmd = "nuget pack Isg.EntityFramework.Interceptors.SoftDelete.nuspec -version $version"
$cmd
Invoke-Expression $cmd

