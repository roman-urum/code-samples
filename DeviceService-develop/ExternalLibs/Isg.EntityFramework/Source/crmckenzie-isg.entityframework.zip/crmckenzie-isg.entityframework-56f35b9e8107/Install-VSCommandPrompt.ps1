#Set environment variables for Visual Studio Command Prompt
$vspath = (get-childitem env:VS100COMNTOOLS).Value
$vsbatchfile = "vsvars32.bat";
$vsfullpath = [System.IO.Path]::Combine($vspath, $vsbatchfile);

#$_ shortcut represents arguments
pushd $vspath
cmd /c $vsfullpath + "&set" |
foreach {
	if ($_ -match �=�) {
	$v = $_.split(�=�);
	set-item -force -path "ENV:\$($v[0])"  -value "$($v[1])"
	}
}
popd
write-host "Visual Studio 2010 Command Prompt variables set." -ForegroundColor Blue