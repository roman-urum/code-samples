﻿using System;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using Isg.EntityFramework.Interceptors.Auditable;
using Isg.EntityFramework.Interceptors.TestDbContext;
using NUnit.Framework;

namespace Isg.EntityFramework.Interceptors.SoftDelete.Tests
{
    [TestFixture]
    public class SoftDeleteChangeInterceptorTests
    {
        [SetUp]
        public void BeforeEachTest()
        {
            InterceptorProvider.SetInterceptorProvider(
                new DefaultInterceptorProvider(
                    new SoftDeleteChangeInterceptor(), 
                    new AuditableChangeInterceptor(System.Threading.Thread.CurrentPrincipal, new Clock())));

            Database.DefaultConnectionFactory = new SqlCeConnectionFactory("System.Data.SqlServerCe.4.0");
            Database.SetInitializer(new DropCreateDatabaseAlways<CustomerDbContext>());

            using (var dataContext = new CustomerDbContext())
            {
                if (dataContext.Database.Exists())
                    dataContext.Database.Delete();
                dataContext.Database.Create();
            }
        }

        [Test]
        public void Delete()
        {
            var name = Guid.NewGuid().ToString();

            using (var db = new CustomerDbContext())
            {
                var customer = new Customer {IsDeleted = false, Name = name};
                db.Customers.Add(customer);
                db.SaveChanges();
            }

            using (var db = new CustomerDbContext())
            {
                var customer = db.Customers.SingleOrDefault(i => i.Name == name);
                db.Customers.Remove(customer);
                db.SaveChanges();
            }

            using (var db = new CustomerDbContext())
            {
                var customer = db.Customers.SingleOrDefault(i => i.Name == name);
                Assert.That(customer, Is.Not.Null);
                Assert.That(customer.IsDeleted, Is.True);
            }
        }
    }
}