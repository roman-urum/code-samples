﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using Isg.EntityFramework.Interceptors.TestDbContext;
using NSubstitute;
using NUnit.Framework;

namespace Isg.EntityFramework.Interceptors.Tests
{
    [TestFixture]
    public class DbContextBaseTests
    {

        [SetUp]
        public void BeforeEachTest()
        {
            Database.DefaultConnectionFactory = new SqlCeConnectionFactory("System.Data.SqlServerCe.4.0");
            Database.SetInitializer(new DropCreateDatabaseAlways<CustomerDbContext>());

            using (var dataContext = new CustomerDbContext())
            {
                if (dataContext.Database.Exists())
                    dataContext.Database.Delete();
                dataContext.Database.Create();
            }
        }

        [Test]
        public void CreateInterceptorContext()
        {
            // Arrange
            InterceptionContext context = null;
            var stub = Substitute.For<IInterceptor>();
            stub.WhenForAnyArgs(i => i.Before(null))
                .Do(callinfo => context = callinfo.Arg<InterceptionContext>());

            InterceptorProvider.SetInterceptorProvider(new DefaultInterceptorProvider(stub));

            // Act
            var customer = new Customer()
                               {
                                   CreateDate = DateTime.Now,
                                   CreateUser = "Foo",
                                   UpdateDate = DateTime.Now,
                                   UpdateUser = "Bar",
                               };
            using (var db = new CustomerDbContext())
            {
                db.Customers.Add(customer);
                db.SaveChanges();
            }

            // Assert
            Assert.That(context, Is.Not.Null);
            var entries = context.Entries.ToList();
            Assert.That(entries, Has.Count.EqualTo(1));

            var entry = entries.First();
            Assert.That(context.EntriesByState.Contains(EntityState.Added));
            Assert.That(context.EntriesByState[EntityState.Added].Contains(entry));
        }

    }
}