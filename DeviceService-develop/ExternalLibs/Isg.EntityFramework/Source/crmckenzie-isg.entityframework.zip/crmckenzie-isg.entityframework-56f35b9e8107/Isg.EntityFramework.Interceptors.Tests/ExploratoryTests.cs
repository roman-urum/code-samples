﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using Isg.EntityFramework.Interceptors.TestDbContext;
using NSubstitute;
using NUnit.Framework;

namespace Isg.EntityFramework.Interceptors.Tests
{
    [TestFixture]
    public class ExploratoryTests
    {
        [SetUp]
        public void BeforeEachTest()
        {
            Database.DefaultConnectionFactory = new SqlCeConnectionFactory("System.Data.SqlServerCe.4.0");
            Database.SetInitializer(new DropCreateDatabaseAlways<CustomerDbContext>());

            using (var dataContext = new CustomerDbContext())
            {
                if (dataContext.Database.Exists())
                    dataContext.Database.Delete();
                dataContext.Database.Create();
            }
        }

        private static Invoice CreateAndSaveCustomerAndInvoice()
        {
            var customer = new Customer()
                               {
                                   CreateDate = DateTime.Now,
                                   CreateUser = "Foo",
                                   UpdateDate = DateTime.Now,
                                   UpdateUser = "Bar",
                               };
            var invoice = new Invoice {Customer = customer, Number = Guid.NewGuid().ToString()};

            using (var db = new CustomerDbContext())
            {
                customer = db.Customers.Add(customer);
                invoice = db.Invoices.Add(invoice);
                db.SaveChanges();
            }

            Assert.That(customer.CustomerId, Is.GreaterThan(0));
            Assert.That(invoice.InvoiceId, Is.GreaterThan(0));
            return invoice;
        }


        private static void StubInterceptor(List<object> argList)
        {
            var stub = Substitute.For<IInterceptor>();
            stub.WhenForAnyArgs(s => s.Before(Arg.Any<InterceptionContext>()))
                .Do(callInfo =>
                        {
                            var arg = (InterceptionContext) callInfo.Args()[0];
                            argList.AddRange(arg.Entries
                                                 .Where(e => e.State == EntityState.Added ||
                                                             e.State == EntityState.Modified ||
                                                             e.State == EntityState.Deleted));
                        });
            InterceptorProvider.SetInterceptorProvider(new DefaultInterceptorProvider(stub));
        }

        [Test]
        public void UpdateBehaviorExplorationTest()
        {
            var argList = new List<object>();

            var stub = Substitute.For<IInterceptor>();
            stub.WhenForAnyArgs(s => s.Before(Arg.Any<InterceptionContext>()))
                .Do(callInfo =>
                        {
                            var context = (InterceptionContext) callInfo.Args()[0];
                            argList.AddRange(from entry in context.Entries
                                             where entry.State == EntityState.Modified
                                             select entry.Entity);
                        });
            InterceptorProvider.SetInterceptorProvider(new DefaultInterceptorProvider(stub));

            var invoice = CreateAndSaveCustomerAndInvoice();

            using (var db = new CustomerDbContext())
            {
                db.Configuration.LazyLoadingEnabled = true;

                var invoiceToUpdate = db.Invoices.Single(i => i.InvoiceId == invoice.InvoiceId);
                invoiceToUpdate.Customer.Name = "Test";

                argList.Clear();
                db.SaveChanges();
                Assert.That(argList.Contains(invoiceToUpdate.Customer));
            }
        }

        [Test]
        public void UpdateForeignKeyPropertyTest()
        {
            var customer1 = new Customer
                                {
                                    Name = "Test1",
                                    CreateDate = DateTime.Now,
                                    CreateUser = "Foo",
                                    UpdateDate = DateTime.Now,
                                    UpdateUser = "Bar",

                                };
            var customer2 = new Customer
                                {
                                    Name = "Test2",
                                   CreateDate = DateTime.Now,
                                   CreateUser = "Foo",
                                   UpdateDate = DateTime.Now,
                                   UpdateUser = "Bar",
                                };
            var invoice1 = new Invoice {Customer = customer1, Number = Guid.NewGuid().ToString()};

            using (var db = new CustomerDbContext())
            {
                db.Customers.Add(customer1);
                db.Customers.Add(customer2);
                db.Invoices.Add(invoice1);
                db.SaveChanges();
            }

            var argList = new List<object>();

            StubInterceptor(argList);

            using (var db = new CustomerDbContext())
            {
                db.Configuration.LazyLoadingEnabled = true;

                var invoiceToUpdate = db.Invoices.Single(i => i.InvoiceId == invoice1.InvoiceId);

                var customer = db.Customers.First(c => c.Name == "Test2");
                invoiceToUpdate.CustomerId = customer.CustomerId;

                argList.Clear();
                db.SaveChanges();
            }

            using (var db = new CustomerDbContext())
            {
                Customer customer = db.Customers.Single(c => c.Name == "Test2");
                var invoice = db.Invoices.Single(i => i.InvoiceId == invoice1.InvoiceId);
                Assert.That(invoice.Customer.CustomerId, Is.EqualTo(customer.CustomerId),
                            "The foreign key reference is not updated.");
                Assert.That(argList.Count, Is.AtLeast(1),
                            "The foreign key reference was updated but the update was not intercepted.");
            }
        }

        [Test]
        public void UpdateNavigationPropertyTest()
        {
            var customer1 = new Customer
                                {
                                    Name = "Test1",
                                    CreateDate = DateTime.Now,
                                    CreateUser = "Foo",
                                    UpdateDate = DateTime.Now,
                                    UpdateUser = "Bar",
                                };
            var customer2 = new Customer
                                {
                                    Name = "Test2",
                                    CreateDate = DateTime.Now,
                                    CreateUser = "Foo",
                                    UpdateDate = DateTime.Now,
                                    UpdateUser = "Bar",
                                };
            var invoice1 = new Invoice {Customer = customer1, Number = Guid.NewGuid().ToString()};

            using (var db = new CustomerDbContext())
            {
                db.Customers.Add(customer1);
                db.Customers.Add(customer2);
                db.Invoices.Add(invoice1);
                db.SaveChanges();
            }

            var argList = new List<object>();

            StubInterceptor(argList);

            using (var db = new CustomerDbContext())
            {
                db.Configuration.LazyLoadingEnabled = true;

                var invoiceToUpdate = db.Invoices.Single(i => i.InvoiceId == invoice1.InvoiceId);

                var customer = db.Customers.Single(c => c.Name == "Test2");
                invoiceToUpdate.Customer = customer;

                argList.Clear();
                db.SaveChanges();
            }

            using (var db = new CustomerDbContext())
            {
                var customer = db.Customers.Single(c => c.Name == "Test2");
                var invoice = db.Invoices.Single(i => i.InvoiceId == invoice1.InvoiceId);
                Assert.That(invoice.Customer.CustomerId, Is.EqualTo(customer.CustomerId),
                            "The foreign key reference is not updated.");
                Assert.That(argList.Count, Is.AtLeast(1),
                            "The foreign key reference was updated but the update was not intercepted.");
            }
        }

        [Test]
        public void UpdateWithNewCustomerBehaviorExplorationTest()
        {
            var argList = new List<object>();

            var stub = Substitute.For<IInterceptor>();
            stub.WhenForAnyArgs(s => s.Before(Arg.Any<InterceptionContext>()))
                .Do(callInfo =>
                        {
                            var context = (InterceptionContext) callInfo.Args()[0];
                            argList.AddRange(from entry in context.Entries
                                             where entry.State == EntityState.Added
                                             select entry.Entity);
                        });
            InterceptorProvider.SetInterceptorProvider(new DefaultInterceptorProvider(stub));

            var invoice = CreateAndSaveCustomerAndInvoice();

            using (var db = new CustomerDbContext())
            {
                db.Configuration.LazyLoadingEnabled = true;

                var invoiceToUpdate = db.Invoices.Single(i => i.InvoiceId == invoice.InvoiceId);
                invoiceToUpdate.Customer = new Customer()
                                               {
                                                   Name = "Test",
                                                   CreateDate = DateTime.Now,
                                                   CreateUser = "Foo",
                                                   UpdateDate = DateTime.Now,
                                                   UpdateUser = "Bar",

                                               };

                argList.Clear();
                db.SaveChanges();
                Assert.That(argList.Contains(invoiceToUpdate.Customer));
                Assert.That(invoiceToUpdate.Customer.CustomerId, Is.GreaterThan(0));
                Assert.That(invoiceToUpdate.Customer.CustomerId, Is.Not.EqualTo(invoice.Customer.CustomerId));
            }
        }
    }
}