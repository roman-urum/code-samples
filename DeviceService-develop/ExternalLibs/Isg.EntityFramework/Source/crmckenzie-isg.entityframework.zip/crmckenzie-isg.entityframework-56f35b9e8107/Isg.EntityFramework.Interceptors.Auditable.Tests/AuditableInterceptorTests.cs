﻿using System;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Security.Principal;
using Isg.EntityFramework.Interceptors.TestDbContext;
using NSubstitute;
using NUnit.Framework;

namespace Isg.EntityFramework.Interceptors.Auditable.Tests
{
    [TestFixture]
    public class AuditableInterceptorTests
    {
        [SetUp]
        public void BeforeEachTest()
        {
            this.Principal = Substitute.For<IPrincipal>();
            this.Clock = Substitute.For<IClock>();

            this.Principal.Identity.Name.Returns("TestUser");
            this.Clock.Now.Returns(DateTime.Now);

            InterceptorProvider.SetInterceptorProvider(
                new DefaultInterceptorProvider(
                    new AuditableChangeInterceptor(this.Principal, this.Clock)));

            Database.DefaultConnectionFactory = new SqlCeConnectionFactory("System.Data.SqlServerCe.4.0");
            Database.SetInitializer(new DropCreateDatabaseAlways<CustomerDbContext>());

            using (var dataContext = new CustomerDbContext())
            {
                if (dataContext.Database.Exists())
                    dataContext.Database.Delete();
                dataContext.Database.Create();
            }
        }

        protected IClock Clock { get; set; }

        protected IPrincipal Principal { get; set; }

        [Test]
        public void InsertAuditable()
        {
            using (var db = new CustomerDbContext())
            {
                var customer = new Customer { IsDeleted = false, Name = "Foo" };
                db.Customers.Add(customer);
                db.SaveChanges();

                Assert.That(customer.CreateDate, Is.EqualTo(this.Clock.Now));
                Assert.That(customer.UpdateDate, Is.EqualTo(this.Clock.Now));
                Assert.That(customer.CreateUser, Is.EqualTo(this.Principal.Identity.Name));
                Assert.That(customer.UpdateUser, Is.EqualTo(this.Principal.Identity.Name));
            }            
        }

        [Test]
        public void UpdateAuditable()
        {
            int customerId = 0;
            using (var db = new CustomerDbContext())
            {
                var customer = new Customer { IsDeleted = false, Name = "Foo" };
                db.Customers.Add(customer);
                db.SaveChanges();

                Assert.That(customer.CreateUser, Is.EqualTo(this.Principal.Identity.Name));
                Assert.That(customer.CreateDate, Is.EqualTo(this.Clock.Now));
                Assert.That(customer.UpdateDate, Is.EqualTo(this.Clock.Now));
                Assert.That(customer.UpdateUser, Is.EqualTo(this.Principal.Identity.Name));

                customerId = customer.CustomerId;
            }            

            this.Principal.Identity.Name.Returns("Some other user");
            this.Clock.Now.Returns(Clock.Now);

            using (var db = new CustomerDbContext())
            {
                var customer = db.Customers.First(row => row.CustomerId == customerId);

                customer.Name = "Bar";
                db.SaveChanges();

                Assert.That(customer.CreateDate, Is.Not.EqualTo(Clock.Now));
                Assert.That(customer.CreateUser, Is.Not.EqualTo(this.Principal.Identity.Name));
                Assert.That(customer.UpdateDate, Is.EqualTo(this.Clock.Now));
                Assert.That(customer.UpdateUser, Is.EqualTo(this.Principal.Identity.Name));



            }
        }
    }
}
