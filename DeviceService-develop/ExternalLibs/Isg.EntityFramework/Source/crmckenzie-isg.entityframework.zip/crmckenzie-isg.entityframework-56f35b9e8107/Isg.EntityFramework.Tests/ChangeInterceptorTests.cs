﻿using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using FizzWare.NBuilder;
using Isg.EntityFramework.Interceptors;
using Isg.EntityFramework.Interceptors.TestDbContext;
using NUnit.Framework;

namespace Isg.EntityFramework.Tests
{
    [TestFixture]
    public class ChangeInterceptorTests
    {
        [SetUp]
        public void BeforeAnyEachRuns()
        {
            this.Interceptor = new FakeCustomerInterceptor();

            InterceptorProvider.SetInterceptorProvider(new DefaultInterceptorProvider(this.Interceptor));

            Database.DefaultConnectionFactory = new SqlCeConnectionFactory("System.Data.SqlServerCe.4.0");
            Database.SetInitializer(new DropCreateDatabaseAlways<CustomerDbContext>());

            using (var dataContext = new CustomerDbContext())
            {
                if (dataContext.Database.Exists())
                    dataContext.Database.Delete();
                dataContext.Database.Create();
            }
        }

        protected FakeCustomerInterceptor Interceptor { get; set; }

        [Test]
        public void OnInsert_Customer()
        {
            int customerId = 0;
            Customer customer;
            using (var db = new CustomerDbContext())
            {
                customer = Builder<Customer>.CreateNew().Build();
                db.Customers.Add(customer);
                db.SaveChanges();

                customerId = customer.CustomerId;
            }

            Assert.That(this.Interceptor.HasCallMatching("OnBefore", customer));
            Assert.That(this.Interceptor.HasCallMatching("OnAfter", customer));
            Assert.That(this.Interceptor.HasCallMatching("OnBeforeInsert", customer));
            Assert.That(this.Interceptor.HasCallMatching("OnAfterInsert", customer));
            Assert.That(this.Interceptor.HasCallMatching("OnBeforeUpdate", customer), Is.False);
            Assert.That(this.Interceptor.HasCallMatching("OnAfterUpdate", customer), Is.False);
        }

        [Test]
        public void OnUpdate_Customer()
        {
            int customerId = 0;
            Customer customer;
            using (var db = new CustomerDbContext())
            {
                customer = Builder<Customer>.CreateNew().Build();
                db.Customers.Add(customer);
                db.SaveChanges();

                customerId = customer.CustomerId;
            }

            using (var db = new CustomerDbContext())
            {
                customer = db.Customers.First(row => row.CustomerId == customerId);

                customer.Name = "Bar";
                db.SaveChanges();
            }

            
            Assert.That(this.Interceptor.HasCallMatching("OnBefore", customer));
            Assert.That(this.Interceptor.HasCallMatching("OnAfter", customer));
            Assert.That(this.Interceptor.HasCallMatching("OnBeforeUpdate", customer));
            Assert.That(this.Interceptor.HasCallMatching("OnAfterUpdate", customer));
        }

        [Test]
        public void OnDelete_Customer()
        {
            int customerId = 0;
            Customer customer;
            using (var db = new CustomerDbContext())
            {
                customer = Builder<Customer>.CreateNew().Build();
                db.Customers.Add(customer);
                db.SaveChanges();

                customerId = customer.CustomerId;
            }

            using (var db =new CustomerDbContext())
            {
                customer = db.Customers.First(row => row.CustomerId == customerId);
                db.Customers.Remove(customer);

                db.SaveChanges();
            }

            Assert.That(this.Interceptor.HasCallMatching("OnBefore", customer));
            Assert.That(this.Interceptor.HasCallMatching("OnBeforeDelete", customer));
            Assert.That(this.Interceptor.HasCallMatching("OnAfter", customer));
            Assert.That(this.Interceptor.HasCallMatching("OnAfterDelete", customer));
        }

        [Test]
        public void OnInsert_Invoice()
        {
            Invoice invoice;
            using (var db = new CustomerDbContext())
            {
                var customer = Builder<Customer>
                    .CreateNew()
                    .Build()
                    ;

                db.Customers.Add(customer);
                
                invoice = Builder<Invoice>.CreateNew().Build();
                invoice.Customer = customer;

                db.Invoices.Add(invoice);
                db.SaveChanges();
            }

            Assert.That(this.Interceptor.HasCallMatching("OnBefore", invoice), Is.False);
            Assert.That(this.Interceptor.HasCallMatching("OnAfter", invoice), Is.False);
            Assert.That(this.Interceptor.HasCallMatching("OnBeforeInsert", invoice), Is.False);
            Assert.That(this.Interceptor.HasCallMatching("OnAfterInsert", invoice), Is.False);
            Assert.That(this.Interceptor.HasCallMatching("OnBeforeUpdate", invoice), Is.False);
            Assert.That(this.Interceptor.HasCallMatching("OnAfterUpdate", invoice), Is.False);
        }

        [Test]
        public void OnUpdate_Invoice()
        {
            int invoiceId = 0;
            Invoice invoice;
            using (var db = new CustomerDbContext())
            {
                var customer = Builder<Customer>
                    .CreateNew()
                    .Build()
                    ;

                db.Customers.Add(customer);

                invoice = Builder<Invoice>.CreateNew().Build();
                invoice.Customer = customer;

                db.Invoices.Add(invoice);
                db.SaveChanges();

                invoiceId = invoice.CustomerId;
            }

            using (var db = new CustomerDbContext())
            {
                invoice = db.Invoices.First(row => row.InvoiceId == invoiceId);

                invoice.Number = "Bar";
                db.SaveChanges();
            }


            Assert.That(this.Interceptor.HasCallMatching("OnBefore", invoice), Is.False);
            Assert.That(this.Interceptor.HasCallMatching("OnAfter", invoice), Is.False);
            Assert.That(this.Interceptor.HasCallMatching("OnBeforeUpdate", invoice), Is.False);
            Assert.That(this.Interceptor.HasCallMatching("OnAfterUpdate", invoice), Is.False);
        }

        [Test]
        public void OnDelete_Invoice()
        {
            int invoiceId = 0;
            Invoice invoice;
            using (var db = new CustomerDbContext())
            {
                var customer = Builder<Customer>
                    .CreateNew()
                    .Build()
                    ;

                db.Customers.Add(customer);

                invoice = Builder<Invoice>.CreateNew().Build();
                invoice.Customer = customer;

                db.Invoices.Add(invoice);
                db.SaveChanges();

                invoiceId = invoice.CustomerId;
            }

            using (var db = new CustomerDbContext())
            {
                invoice = db.Invoices.First(row => row.InvoiceId == invoiceId);
                db.Invoices.Remove(invoice);

                db.SaveChanges();
            }

            Assert.That(this.Interceptor.HasCallMatching("OnBefore", invoice), Is.False);
            Assert.That(this.Interceptor.HasCallMatching("OnBeforeDelete", invoice), Is.False);
            Assert.That(this.Interceptor.HasCallMatching("OnAfter", invoice), Is.False);
            Assert.That(this.Interceptor.HasCallMatching("OnAfterDelete", invoice), Is.False);
        }


    }
}