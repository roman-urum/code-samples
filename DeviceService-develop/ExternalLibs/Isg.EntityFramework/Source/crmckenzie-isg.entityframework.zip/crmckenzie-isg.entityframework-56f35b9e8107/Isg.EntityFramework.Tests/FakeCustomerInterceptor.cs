using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using Isg.EntityFramework.Interceptors;
using Isg.EntityFramework.Interceptors.TestDbContext;

namespace Isg.EntityFramework.Tests
{
    public class TrackedInterceptorArguments
    {
        public string Event { get; set; }
        public DbEntityEntry DbEntityEntry { get; set; }
        public EntityState State { get; set; }
        public InterceptionContext Context { get; set; }
        public Customer Entity { get; set; }
    }

    public class FakeCustomerInterceptor : ChangeInterceptor<Customer>
    {
        private readonly List<TrackedInterceptorArguments> _trackedCalls = new List<TrackedInterceptorArguments>();

        public bool HasCallMatching(string key, object entity)
        {

            var results = _trackedCalls
                .Where(row => row.Event == key)
                .Where(row => row.Entity == entity)
                .ToList()
                ;

            return results.Any();
        }



        public bool HasCallMatching(string eventName, Func<TrackedInterceptorArguments, bool> constraint = null)
        {
            if (constraint == null)
                constraint = o => true;

            var results = _trackedCalls
                .Where(row => row.Event == eventName)
                .Where(row => constraint.Invoke(row))
                .ToList()
                ;

            return results.Any();
        }

        protected override void OnAfter(DbEntityEntry item, EntityState state, InterceptionContext context)
        {
            var args = new TrackedInterceptorArguments()
                       {
                           Event = "OnAfter",
                           DbEntityEntry = item,
                           Entity = (Customer)item.Entity,
                           State = state,
                           Context = context,
                       };
            Track(args);
            base.OnAfter(item, state, context);
        }

        protected override void OnBefore(DbEntityEntry item, EntityState state, InterceptionContext context)
        {
            var args = new TrackedInterceptorArguments()
            {
                Event = "OnBefore",
                DbEntityEntry = item,
                Entity = (Customer)item.Entity,
                State = state,
                Context = context,
            };
            Track(args);
            base.OnBefore(item, state, context);
        }

        private void Track(TrackedInterceptorArguments args)
        {
            this._trackedCalls.Add(args);
        }

        protected override void OnAfterInsert(DbEntityEntry entry, Customer item, InterceptionContext context)
        {
            var args = new TrackedInterceptorArguments()
            {
                Event = "OnAfterInsert",
                DbEntityEntry = entry,
                Entity = item,
                Context = context,
                State = entry.State,
            };
            Track(args);
            base.OnAfterInsert(entry, item, context);
        }

        protected override void OnAfterDelete(DbEntityEntry entry, Customer item, InterceptionContext context)
        {
            var args = new TrackedInterceptorArguments()
            {
                Event = "OnAfterDelete",
                DbEntityEntry = entry,
                Entity = item,
                Context = context,
                State = entry.State,
            };
            Track(args);
            base.OnAfterDelete(entry, item, context);
        }

        protected override void OnAfterUpdate(DbEntityEntry entry, Customer item, InterceptionContext context)
        {
            var args = new TrackedInterceptorArguments()
            {
                Event = "OnAfterUpdate",
                DbEntityEntry = entry,
                Entity = item,
                Context = context,
                State = entry.State,
            };
            Track(args);
            base.OnAfterUpdate(entry, item, context);
        }

        protected override void OnBeforeUpdate(DbEntityEntry entry, Customer item, InterceptionContext context)
        {
            var args = new TrackedInterceptorArguments()
            {
                Event = "OnBeforeUpdate",
                DbEntityEntry = entry,
                Entity = item,
                Context = context,
                State = entry.State
            };
            Track(args);
            base.OnBeforeUpdate(entry, item, context);
        }

        protected override void OnBeforeDelete(DbEntityEntry entry, Customer item, InterceptionContext context)
        {
            var args = new TrackedInterceptorArguments()
            {
                Event = "OnBeforeDelete",
                DbEntityEntry = entry,
                Entity = item,
                Context = context,
                State = entry.State,
            };
            Track(args);
            base.OnBeforeDelete(entry, item, context);
        }

        protected override void OnBeforeInsert(DbEntityEntry entry, Customer item, InterceptionContext context)
        {
            var args = new TrackedInterceptorArguments()
            {
                Event = "OnBeforeInsert",
                DbEntityEntry = entry,
                Entity = item,
                Context = context,
                State = entry.State,
            };
            Track(args);
            base.OnBeforeInsert(entry, item, context);
        }
    }
}